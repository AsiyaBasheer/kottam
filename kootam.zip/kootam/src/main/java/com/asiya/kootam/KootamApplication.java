package com.asiya.kootam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KootamApplication {

	public static void main(String[] args) {
		SpringApplication.run(KootamApplication.class, args);
	}

}
